package com.citi.cmb.gce.accountservices.quartz.dao;

import com.citi.cmb.gce.accountservices.quartz.entity.QuartzAudit;

public interface QuartzAuditDao {
public void saveAudit(QuartzAudit quartzAudit);
}
