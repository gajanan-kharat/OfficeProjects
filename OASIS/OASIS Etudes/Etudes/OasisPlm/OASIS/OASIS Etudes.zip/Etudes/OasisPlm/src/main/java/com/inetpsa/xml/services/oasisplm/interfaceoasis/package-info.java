@javax.xml.bind.annotation.XmlSchema(namespace = "http://xml.inetpsa.com/Services/OasisPLM/InterfaceOasis")
package com.inetpsa.xml.services.oasisplm.interfaceoasis;
